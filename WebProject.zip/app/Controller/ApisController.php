
<?php 

App::uses('AppController', 'Controller');

/**
 * Main controller of our small application
 *
 * @author ...
 */
class ApisController extends AppController
{  public function index()
    {
       
    } 
    public $uses = array('Member', 'Gathering', 'Device', 'Log'); 

    /**
     * index method : first page
     *
     * @return void
     */
    public function registerobject()
    {  
        if ($this->request->is('post'))       
            pr($this->request->data); 
            $this->Device->addDevice($this->request->data['objectadd']['compte'],$this->request->data['objectadd']['appareil'],$this->request->data['objectadd']['description'],$this->request->data['objectadd']['serial']);
    }
 
    }
  

?>