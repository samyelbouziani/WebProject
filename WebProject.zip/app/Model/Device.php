<?php

App::uses('AppModel', 'Model');

class Device extends AppModel {

public $displayField = 'serial';

public $belongsTo = array('Member' => array('className' => 'Member', 'foreignKey' => 'member_id', 'conditions' => '', 'fields' => '', 'order' => ''));

function addDevice($member_id, $serial, $description, $trusted){ 
    	$this->create();
    	$this->save(array('member_id'=>$member_id, 'serial'=>$serial, 'description'=>$description, 'trusted'=>$trusted));
    }
function validateDevice($id){ 
    	$this->create();
    	$this->save(array('id'=>$id,'trusted'=>1));
    }

}

?>