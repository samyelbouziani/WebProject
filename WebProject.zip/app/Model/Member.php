<?php

App::uses('AppModel', 'Model');

class Member extends AppModel {

	function addMember($email, $password){ 
    	$this->create();
    	$this->save(array('email'=>$email, 'password'=>$password));
    }

    
    function modifyMember($id, $email, $password){ 
    	$this->create();
    	$this->save(array('id'=>$id,'email'=>$email, 'password'=>$password));
    }
}


?>