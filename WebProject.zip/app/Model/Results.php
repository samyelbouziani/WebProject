<?php

App::uses('AppModel', 'Model');

class Results extends AppModel {

	function addResults($member_id, $contest_id, $points){ 
    	$this->create();
    	$this->save(array('member_id'=>$member_id, 'contest_id'=>$contest_id, 'points'=>$points));
    }
}


?>